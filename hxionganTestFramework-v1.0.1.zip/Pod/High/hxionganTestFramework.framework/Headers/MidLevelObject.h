//
//  MidLevelObject.h
//  hxionganTestFramework
//
//  Created by hxiongan on 2019/3/11.
//  Copyright © 2019年 ahx. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MidLevelObject : NSObject

- (NSString *)levelInfo;

@end

NS_ASSUME_NONNULL_END
